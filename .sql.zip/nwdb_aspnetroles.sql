insert into nwdb.aspnetroles (Id, Name, NormalizedName, ConcurrencyStamp) values (1, 'Admin', 'ADMIN', 'd5a1945c-0c3f-4c66-a490-25c2513b3a2a');
insert into nwdb.aspnetroles (Id, Name, NormalizedName, ConcurrencyStamp) values (2, 'Client', 'CLIENT', '53606884-8e3f-4802-af4e-27a828a1d296');
