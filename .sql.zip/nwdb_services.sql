insert into nwdb.services (Id, ServiceViewId) values (1, 1);
insert into nwdb.services (Id, ServiceViewId) values (2, 2);
insert into nwdb.services (Id, ServiceViewId) values (3, 3);
