insert into nwdb.serviceviews (ServiceId, Title, MainImageName) values (1, 'ОТКАЧКА ЖИДКИХ БЫТОВЫХ ОТХОДОВ', 'Assenizator.png');
insert into nwdb.serviceviews (ServiceId, Title, MainImageName) values (2, 'ВЫВОЗ СТРОИТЕЛЬНОГО И КРУПНОГАБАРИТНОГО МУСОРА', 'KGO.png');
insert into nwdb.serviceviews (ServiceId, Title, MainImageName) values (3, 'ПОЛИВ И ОЧИСТКА ТЕРРИТОРИЙ', 'PolivIOchistkaTerrityriy.png');
