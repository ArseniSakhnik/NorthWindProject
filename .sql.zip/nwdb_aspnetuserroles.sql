insert into nwdb.aspnetuserroles (UserId, RoleId) values (1, 1);
