insert into nwdb.__efmigrationshistory (MigrationId, ProductVersion) values ('20220523120223_Init', '5.0.10');
